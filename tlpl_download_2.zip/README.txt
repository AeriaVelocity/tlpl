Take it and Like it Public License, version 2

To use, add the attached LICENSE.txt file to your code or with any binaries.
If you want to, put this disclaimer in your program somewhere:

This software is free software -- licensed under the Take it or Like it Public License.
Visit speedstriker243.github.io/tlpl for more information.