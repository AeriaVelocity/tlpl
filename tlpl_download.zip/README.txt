Take it and Like it Public License
Version 1

To use, add the attached LICENSE.txt file to your code or with any binaries.
Ensure you add the following disclaimer somewhere in your program:

You should have received a copy of the Take it and Like it Public License with this program.
If not, please visit https://speedstriker243.github.io/tlpl for the license and information about it.